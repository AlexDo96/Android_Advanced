package project.mac.recycleviewdemo1;

import android.support.v4.view.PagerAdapter;

/**
 * Created by mac on 9/26/15.
 */
public class Logo {
    String name;
    int hinh;
    public Logo(String name,int hinh)
    {
        this.name=name;
        this.hinh=hinh;
    }
}
