package project.mac.recycleviewdemo2;

/**
 * Created by mac on 9/26/15.
 */
public class Data {
    String ten;
    public Data(String ten)
    {
        this.ten=ten;
    }
}
